#ifndef LIB_KEY_H
#define LIB_KEY_H

/*
 * A function that can be called when a key sequence has been typed.
*/
typedef void (*LibkeySequenceCallback)(struct LibkeyState *state, int count, const char *arguments);

/*
 * A possible chain of keys that invokes a callback once the
 * chain has been typed.
 *
 * @field sequence: the keys that need to be pressed
 * @field callback: the function to invoke
*/
struct LibkeySequence {
    char *sequence;
    LibkeySequenceCallback callback;
}

/*
 * A mode, which contains a unique identifier, the name, and
 * an array of keyboard sequences which can be executed while
 * the mode is selected.
 *
 * @field name: the name of the mode
 * @field logical_size: the number of sequences in the array
 * @field physical_size: the maximum number of sequences
 * @field contents: the array of key sequences
*/
struct LibkeyMode {
    char *name;
    unsigned int logical_size;
    unsigned int physical_size;
    struct LibkeySequence *contents;
}

/*
 * The state container for libkey. Contains all modes, and is the
 * main part of the keybinding system
 *
 * @field mode: the selected mode
 * @field logical_size: the number of modes in the array
 * @field physical_size: the maximum number of modes
 * @field contents: the array of modes
*/
struct LibkeyState {
    struct LibkeyMode mode;
    unsigned int logical_size;
    unsigned int physical_size;
    struct LibkeyMode *contents
};

#endif
