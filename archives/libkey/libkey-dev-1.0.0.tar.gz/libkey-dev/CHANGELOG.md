VERSION: 1.0.0
DATE: January 8th, 2021

+ Added `libkey.h` header
+ Added `LibkeySequence`, `LibkeyMode`, and `LibkeyState` structures, along with documentation.
