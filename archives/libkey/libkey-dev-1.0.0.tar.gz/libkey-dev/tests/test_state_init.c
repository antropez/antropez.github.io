#include "common.h"

int main(void) {
    struct LibkeyMode modes[10] = {0};
    struct LibkeySequence sequences[10] = {0};
    struct LibkeyState state = libkey_state_init();

    assert(state.modes.physical_size == 0);
    assert(state.modes.contents == NULL);
    assert(state.sequences.physical_size == 0);
    assert(state.sequences.contents == NULL);

    state = libkey_state_init_modes(state, 10, modes);
    
    assert(state.modes.physical_size == 10);
    assert(state.modes.contents == modes);

    state = libkey_state_init_sequences(state, 10, sequences);
    
    assert(state.sequences.physical_size == 10);
    assert(state.sequences.contents == sequences);

    return EXIT_SUCCESS;
}
