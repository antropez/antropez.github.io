VERSION: 1.0.1
DATE: January 8th, 2021

+ Added `libkey.c` source file
+ Added `libkey_state_init` function
+ Fixed up `tests/test_state_init` to be inline with the new API.
