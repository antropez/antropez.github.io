#ifndef LIB_KEY_H
#define LIB_KEY_H

#include <stddef.h>

struct LibkeyState;

/*
 * A function that can be called when a key sequence has been typed.
*/
typedef void (*LibkeySequenceCallback)(struct LibkeyState *state, int count, const char *arguments);

/*
 * A possible chain of keys that invokes a callback once the
 * chain has been typed.
 *
 * @field sequence: the keys that need to be pressed
 * @field callback: the function to invoke
*/
struct LibkeySequence {
    char *sequence;
    LibkeySequenceCallback callback;
};

/*
 * A mode, which contains a unique identifier, the name, and
 * an array of keyboard sequences which can be executed while
 * the mode is selected.
 *
 * @field name: the name of the mode
 * @field logical_size: the number of sequences in the array
 * @field physical_size: the maximum number of sequences
 * @field contents: the array of key sequences
*/
struct LibkeyMode {
    char *name;
    unsigned int logical_size;
    unsigned int physical_size;
    struct LibkeySequence *contents;
};

/*
 * The state container for libkey. Contains all modes, and is the
 * main part of the keybinding system
 *
 * @field mode: the selected mode
 * @field logical_size: the number of modes in the array
 * @field physical_size: the maximum number of modes
 * @field contents: the array of modes
*/
struct LibkeyState {
    struct LibkeyMode mode;
    unsigned int logical_size;
    unsigned int physical_size;
    struct LibkeyMode *contents;
};

/*
 * Initializes a new state container with an array of modes that
 * will be filled up.
 *
 * @param length: the maximum length of the mode array
 * @param modes: the stack array to use for the modes
 * @return: the new state container
*/
struct LibkeyState libkey_state_init(size_t length, struct LibkeyMode *modes);

#endif
