#ifndef LIB_KEY_COMMON_H
#define LIB_KEY_COMMON_H

#include <stdlib.h>
#include <assert.h>

#include "../src/libkey.h"

#endif
