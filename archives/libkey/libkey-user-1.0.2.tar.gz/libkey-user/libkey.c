#include <stdio.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <ncurses.h>
#include "libkey.h"
#define LIBKEY_MODE_NAME        32
#define LIBKEY_SEQUENCE_NAME    32

























struct LibkeyState libkey_init(size_t length, struct LibkeyMode *modes) {
    struct LibkeyState new_state = {0};

    new_state.physical_size = length;
    new_state.contents = modes;

    return new_state;
}

struct LibkeyMode *libkey_add_mode(struct LibkeyState *state, const char *name, size_t length, struct LibkeySequence *sequences) {
    int exists = libkey_mode_exists(state, name);
    struct LibkeyMode new_mode = {0};

    if(strlen(name) > 32)
        libkey_error("libkey_add_mode: mode name '%s' is too long. maximum %i characters.\n", name, 32);

    if(exists == 1)
        libkey_error("libkey_add_mode: attempt to add a mode '%s' that is already defined.\n", name);

    strncat(new_mode.name, name, 32);
    new_mode.physical_size = length;
    new_mode.contents = sequences;

    
    if((state)->logical_size == (state)->physical_size) {
        fprintf(stderr, "array_append: attempt to append value \"%s\" into full array.\n",  "new_mode");
            exit(EXIT_FAILURE);
        
    }

    (state)->contents[(state)->logical_size] = (new_mode);
    (state)->logical_size++
;

    return state->contents + (state->logical_size - 1);
}

struct LibkeySequence *libkey_add_sequence(struct LibkeyMode *mode, const char *sequence, LibkeySequenceCallback callback) {
    int exists = libkey_sequence_exists(mode, sequence);
    struct LibkeySequence new_sequence = {0};

    if(strlen(sequence) > 32)
        libkey_error("libkey_add_sequence: sequence '%s' is too long. maximum %i characters.\n", sequence, 32);

    if(exists == 1)
        libkey_error("libkey_add_sequence: attempt to add a sequence '%s' that is already defined.\n", sequence);

    strncat(new_sequence.sequence, sequence, 32);
    new_sequence.callback = callback;

    
    if((mode)->logical_size == (mode)->physical_size) {
        fprintf(stderr, "array_append: attempt to append value \"%s\" into full array.\n",  "new_sequence");
            exit(EXIT_FAILURE);
        
    }

    (mode)->contents[(mode)->logical_size] = (new_sequence);
    (mode)->logical_size++
;

    return mode->contents + (mode->logical_size - 1);
}

int libkey_mode_exists(struct LibkeyState *state, const char *name) {
    int exists = 0;
    struct LibkeyMode comparison_mode = {0};

    strncat(comparison_mode.name, name, 32);
    exists = 
    -1;

    do {
        size_t __dm4_array_search_index = 0;

        for(__dm4_array_search_index = 0; __dm4_array_search_index < (state)->logical_size; __dm4_array_search_index++) {
            if(libkey_mode_compare((state)->contents[__dm4_array_search_index], comparison_mode) == 0) {
                    continue;
                }
            

            (exists) = (int) __dm4_array_search_index;
            break;
        }
    } while(0)
;

    return exists != -1;
}

int libkey_sequence_exists(struct LibkeyMode *mode, const char *sequence) {
    int exists = 0;
    struct LibkeySequence comparison_sequence = {0};

    strncat(comparison_sequence.sequence, sequence, 32);
    exists = 
    -1;

    do {
        size_t __dm4_array_search_index = 0;

        for(__dm4_array_search_index = 0; __dm4_array_search_index < (mode)->logical_size; __dm4_array_search_index++) {
            if(libkey_sequence_compare((mode)->contents[__dm4_array_search_index], comparison_sequence) == 0) {
                    continue;
                }
            

            (exists) = (int) __dm4_array_search_index;
            break;
        }
    } while(0)
;

    return exists != -1;
}

int libkey_mode_compare(struct LibkeyMode mode_a, struct LibkeyMode mode_b) {
    return strcmp(mode_a.name, mode_b.name) == 0;
}

int libkey_sequence_compare(struct LibkeySequence sequence_a, struct LibkeySequence sequence_b) {
    return strcmp(sequence_a.sequence, sequence_b.sequence) == 0;
}

void libkey_error(const char *format, ...) {
    va_list specifiers = {0};

    va_start(specifiers, format);
    vfprintf(stderr, format, specifiers);
    va_end(specifiers);

    exit(EXIT_FAILURE);
}
int libkey_count_prefixes(struct LibkeyState *state, const char *prefix) {
    int prefixed = 0;
    unsigned int index = 0;

    for(index = 0; index < state->mode.logical_size; index++) {
        struct LibkeySequence sequence = state->mode.contents[index];
    }

    return prefixed;
}

void libkey_scan(struct LibkeyState *state) {
    int character = getch();
    size_t length = strlen(state->sequence);

    if(length == 32) {
        memset(state->sequence, 0, 32);

        return;
    }


}
void libkey_sequence_validate(struct LibkeyMode mode, const char *sequence) {

}
