#include "libkey.h"
#include <stddef.h>

struct LibkeyState libkey_state_init(size_t length, struct LibkeyMode *modes) {
    struct LibkeyState new_state = {0};

    new_state.physical_size = length;
    new_state.contents = modes;

    return new_state;
}
