VERSION: 1.0.1
DATE: January 11th, 2022

+ Added `qarray_insert`, `qarray_pop`, and `qarray_init`.
+ Added tests for the above three functions.
