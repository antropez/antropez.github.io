#ifndef Q_ARRAY_COMMON_H
#define Q_ARRAY_COMMON_H

#include <assert.h>
#include "../qarray.h"

#define STRING_COMPARE(x, y) \
    strcmp(x, y) == 0

#define STRING_SETTINGS char*, STRING_COMPARE,

struct StringArray {
    unsigned int logical_size;
    unsigned int physical_size;
    char **contents;
}

#endif
