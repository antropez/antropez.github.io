#include "common.h"

int main(void) {
    struct StringArray *array = qarray_init(array, STRING_SETTINGS);
}
