#ifndef Q_ARRAY_H
#define Q_ARRAY_H

#define __QARRAY_SETTINGS _type, _compare, _free,

#ifndef QARRAY_STACKFUL
#define __qarray_init(qarray, _type, _compare, _free) \
    malloc(sizeof(*qarray));

#define qarray_init(qarray, settings) \
    __qarray_init(qarray, settings)

#endif

    

    

#endif
