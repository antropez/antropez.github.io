VERSION: 1.0.0
DATE: January 10th, 2022

+ Added `qarray_init` macro
